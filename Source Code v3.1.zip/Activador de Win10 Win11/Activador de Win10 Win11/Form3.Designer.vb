﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.editiontext = New System.Windows.Forms.Label()
        Me.pyetext = New System.Windows.Forms.Label()
        Me.verusertext = New System.Windows.Forms.Label()
        Me.verostext = New System.Windows.Forms.Label()
        Me.buildtext = New System.Windows.Forms.Label()
        Me.buildlabtext = New System.Windows.Forms.Label()
        Me.buildlabextext = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.osfullname = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.osplataform = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.osversion = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'editiontext
        '
        Me.editiontext.AutoSize = True
        Me.editiontext.Location = New System.Drawing.Point(69, 45)
        Me.editiontext.Name = "editiontext"
        Me.editiontext.Size = New System.Drawing.Size(41, 15)
        Me.editiontext.TabIndex = 0
        Me.editiontext.Text = "Label1"
        '
        'pyetext
        '
        Me.pyetext.AutoSize = True
        Me.pyetext.Location = New System.Drawing.Point(69, 9)
        Me.pyetext.Name = "pyetext"
        Me.pyetext.Size = New System.Drawing.Size(41, 15)
        Me.pyetext.TabIndex = 1
        Me.pyetext.Text = "Label1"
        '
        'verusertext
        '
        Me.verusertext.AutoSize = True
        Me.verusertext.Location = New System.Drawing.Point(69, 80)
        Me.verusertext.Name = "verusertext"
        Me.verusertext.Size = New System.Drawing.Size(41, 15)
        Me.verusertext.TabIndex = 2
        Me.verusertext.Text = "Label1"
        '
        'verostext
        '
        Me.verostext.AutoSize = True
        Me.verostext.Location = New System.Drawing.Point(106, 112)
        Me.verostext.Name = "verostext"
        Me.verostext.Size = New System.Drawing.Size(41, 15)
        Me.verostext.TabIndex = 3
        Me.verostext.Text = "Label1"
        '
        'buildtext
        '
        Me.buildtext.AutoSize = True
        Me.buildtext.Location = New System.Drawing.Point(55, 147)
        Me.buildtext.Name = "buildtext"
        Me.buildtext.Size = New System.Drawing.Size(41, 15)
        Me.buildtext.TabIndex = 4
        Me.buildtext.Text = "Label1"
        '
        'buildlabtext
        '
        Me.buildlabtext.AutoSize = True
        Me.buildlabtext.Location = New System.Drawing.Point(95, 181)
        Me.buildlabtext.Name = "buildlabtext"
        Me.buildlabtext.Size = New System.Drawing.Size(41, 15)
        Me.buildlabtext.TabIndex = 5
        Me.buildlabtext.Text = "Label1"
        '
        'buildlabextext
        '
        Me.buildlabextext.AutoSize = True
        Me.buildlabextext.Location = New System.Drawing.Point(150, 215)
        Me.buildlabextext.Name = "buildlabextext"
        Me.buildlabextext.Size = New System.Drawing.Size(41, 15)
        Me.buildlabextext.TabIndex = 6
        Me.buildlabextext.Text = "Label1"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 15)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Edicion:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 15)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Nombre:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(11, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 15)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Version:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(11, 112)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 15)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Version tecnica:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 147)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 15)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Build:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(11, 181)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 15)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Build tecnica:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(11, 215)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(133, 15)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Build tecnica extendida:"
        '
        'osfullname
        '
        Me.osfullname.AutoSize = True
        Me.osfullname.Location = New System.Drawing.Point(127, 251)
        Me.osfullname.Name = "osfullname"
        Me.osfullname.Size = New System.Drawing.Size(41, 15)
        Me.osfullname.TabIndex = 14
        Me.osfullname.Text = "Label1"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(11, 251)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(110, 15)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Nombre extendido:"
        '
        'osplataform
        '
        Me.osplataform.AutoSize = True
        Me.osplataform.Location = New System.Drawing.Point(85, 284)
        Me.osplataform.Name = "osplataform"
        Me.osplataform.Size = New System.Drawing.Size(41, 15)
        Me.osplataform.TabIndex = 16
        Me.osplataform.Text = "Label1"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(11, 284)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(68, 15)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "Plataforma:"
        '
        'osversion
        '
        Me.osversion.AutoSize = True
        Me.osversion.Location = New System.Drawing.Point(106, 320)
        Me.osversion.Name = "osversion"
        Me.osversion.Size = New System.Drawing.Size(41, 15)
        Me.osversion.TabIndex = 18
        Me.osversion.Text = "Label1"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(12, 320)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(88, 15)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Version interna:"
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(464, 344)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.osversion)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.osplataform)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.osfullname)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.buildlabextext)
        Me.Controls.Add(Me.buildlabtext)
        Me.Controls.Add(Me.buildtext)
        Me.Controls.Add(Me.verostext)
        Me.Controls.Add(Me.verusertext)
        Me.Controls.Add(Me.pyetext)
        Me.Controls.Add(Me.editiontext)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form3"
        Me.Text = "Informacion del OS"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents editiontext As Label
    Friend WithEvents pyetext As Label
    Friend WithEvents verusertext As Label
    Friend WithEvents verostext As Label
    Friend WithEvents buildtext As Label
    Friend WithEvents buildlabtext As Label
    Friend WithEvents buildlabextext As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents osfullname As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents osplataform As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents osversion As Label
    Friend WithEvents Label10 As Label
End Class
