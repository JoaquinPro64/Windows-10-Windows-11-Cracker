﻿Friend Class ManagementObjectSearcher
    Private v As String

    Public Sub New(v As String)
        Me.v = v
    End Sub
End Class
