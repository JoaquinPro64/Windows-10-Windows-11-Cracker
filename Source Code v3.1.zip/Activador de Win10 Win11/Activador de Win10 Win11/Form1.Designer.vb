﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.autobutton = New System.Windows.Forms.Button()
        Me.manualbutton = New System.Windows.Forms.Button()
        Me.pcinfobutton = New System.Windows.Forms.Button()
        Me.appinfobutton = New System.Windows.Forms.Button()
        Me.exitbutton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(220, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Activador De Windows 10 / Windows 11:"
        '
        'autobutton
        '
        Me.autobutton.Location = New System.Drawing.Point(12, 40)
        Me.autobutton.Name = "autobutton"
        Me.autobutton.Size = New System.Drawing.Size(114, 23)
        Me.autobutton.TabIndex = 1
        Me.autobutton.Text = "Modo automatico"
        Me.autobutton.UseVisualStyleBackColor = True
        '
        'manualbutton
        '
        Me.manualbutton.Location = New System.Drawing.Point(179, 40)
        Me.manualbutton.Name = "manualbutton"
        Me.manualbutton.Size = New System.Drawing.Size(96, 23)
        Me.manualbutton.TabIndex = 2
        Me.manualbutton.Text = "Modo manual"
        Me.manualbutton.UseVisualStyleBackColor = True
        '
        'pcinfobutton
        '
        Me.pcinfobutton.Location = New System.Drawing.Point(79, 86)
        Me.pcinfobutton.Name = "pcinfobutton"
        Me.pcinfobutton.Size = New System.Drawing.Size(129, 23)
        Me.pcinfobutton.TabIndex = 3
        Me.pcinfobutton.Text = "Informacion del OS"
        Me.pcinfobutton.UseVisualStyleBackColor = True
        '
        'appinfobutton
        '
        Me.appinfobutton.Location = New System.Drawing.Point(1, 131)
        Me.appinfobutton.Name = "appinfobutton"
        Me.appinfobutton.Size = New System.Drawing.Size(75, 23)
        Me.appinfobutton.TabIndex = 4
        Me.appinfobutton.Text = "Acerca de"
        Me.appinfobutton.UseVisualStyleBackColor = True
        '
        'exitbutton
        '
        Me.exitbutton.Location = New System.Drawing.Point(211, 131)
        Me.exitbutton.Name = "exitbutton"
        Me.exitbutton.Size = New System.Drawing.Size(75, 23)
        Me.exitbutton.TabIndex = 5
        Me.exitbutton.Text = "Salir"
        Me.exitbutton.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(287, 154)
        Me.Controls.Add(Me.exitbutton)
        Me.Controls.Add(Me.appinfobutton)
        Me.Controls.Add(Me.pcinfobutton)
        Me.Controls.Add(Me.manualbutton)
        Me.Controls.Add(Me.autobutton)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Activador de Windows 10 / 11"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents autobutton As Button
    Friend WithEvents manualbutton As Button
    Friend WithEvents pcinfobutton As Button
    Friend WithEvents appinfobutton As Button
    Friend WithEvents exitbutton As Button
End Class
