﻿Public Class Form2
    Private Sub win10home_Click(sender As Object, e As EventArgs) Handles win10home.Click
        System.Diagnostics.Process.Start("Resources\activ_win10\win_10_home.bat")
        Me.Close()
    End Sub

    Private Sub win10homen_Click(sender As Object, e As EventArgs) Handles win10homen.Click
        System.Diagnostics.Process.Start("Resources\activ_win10\win_10_home_n.bat")
        Me.Close()
    End Sub
    Private Sub win10homesl_Click(sender As Object, e As EventArgs) Handles win10homesl.Click
        System.Diagnostics.Process.Start("Resources\activ_win10\win_10_home_single_languaje.bat")
        Me.Close()
    End Sub
    Private Sub win10cs_Click(sender As Object, e As EventArgs) Handles win10cs.Click
        System.Diagnostics.Process.Start("Resources\activ_win10\win_10_home_country_specific.bat")
        Me.Close()
    End Sub
    Private Sub win10pro_Click(sender As Object, e As EventArgs) Handles win10pro.Click
        System.Diagnostics.Process.Start("Resources\activ_win10\win_10_pro.bat")
        Me.Close()
    End Sub
    Private Sub win10pron_Click(sender As Object, e As EventArgs) Handles win10pron.Click
        System.Diagnostics.Process.Start("Resources\activ_win10\win_10_pro_n.bat")
        Me.Close()
    End Sub
    Private Sub win10enterprise_Click(sender As Object, e As EventArgs) Handles win10enterprise.Click
        System.Diagnostics.Process.Start("Resources\activ_win10\win_10_enterprise.bat")
        Me.Close()
    End Sub

    Private Sub win10enterprisen_Click(sender As Object, e As EventArgs) Handles win10enterprisen.Click
        System.Diagnostics.Process.Start("Resources\activ_win10\win_10_enterprise_n.bat")
        Me.Close()
    End Sub
    Private Sub win10edu_Click(sender As Object, e As EventArgs) Handles win10edu.Click
        System.Diagnostics.Process.Start("Resources\activ_win10\win_10_education.bat")
        Me.Close()
    End Sub
    Private Sub win10edun_Click(sender As Object, e As EventArgs) Handles win10edun.Click
        System.Diagnostics.Process.Start("Resources\activ_win10\win_10_education_n.bat")
        Me.Close()
    End Sub
    Private Sub win10enterprise2015ltsb_Click(sender As Object, e As EventArgs) Handles win10enterprise2015ltsb.Click
        System.Diagnostics.Process.Start("Resources\activ_win10\win_10_enterprise_2015_ltsb.bat")
        Me.Close()
    End Sub

    Private Sub win10enterprise2015ltsbn_Click(sender As Object, e As EventArgs) Handles win10enterprise2015ltsbn.Click
        System.Diagnostics.Process.Start("Resources\activ_win10\win_10_2015_ltsb_n.bat")
        Me.Close()
    End Sub

    Private Sub win11home_Click(sender As Object, e As EventArgs) Handles win11home.Click
        System.Diagnostics.Process.Start("Resources\activ_win11\win_11_home.bat")
        Me.Close()
    End Sub
    Private Sub win11homesl_Click(sender As Object, e As EventArgs) Handles win11homesl.Click
        System.Diagnostics.Process.Start("Resources\activ_win11\win_11_home_sl.bat")
        Me.Close()
    End Sub
    Private Sub win11pro_Click(sender As Object, e As EventArgs) Handles win11pro.Click
        System.Diagnostics.Process.Start("Resources\activ_win11\win_11_pro.bat")
        Me.Close()
    End Sub

    Private Sub win11pron_Click(sender As Object, e As EventArgs) Handles win11pron.Click
        System.Diagnostics.Process.Start("Resources\activ_win11\win_11_pro_n.bat")
        Me.Close()
    End Sub
    Private Sub win11edu_Click(sender As Object, e As EventArgs) Handles win11edu.Click
        System.Diagnostics.Process.Start("Resources\activ_win11\win_11_edu.bat")
        Me.Close()
    End Sub
    Private Sub win11edun_Click(sender As Object, e As EventArgs) Handles win11edun.Click
        System.Diagnostics.Process.Start("Resources\activ_win11\win_11_edu_n.bat")
        Me.Close()
    End Sub
    Private Sub win11work_Click(sender As Object, e As EventArgs) Handles win11work.Click
        System.Diagnostics.Process.Start("Resources\activ_win11\win_11_work.bat")
        Me.Close()
    End Sub
    Private Sub win11proforworkn_Click(sender As Object, e As EventArgs) Handles win11proforworkn.Click
        System.Diagnostics.Process.Start("Resources\activ_win11\win_11_proforworkn.bat")
        Me.Close()
    End Sub
End Class