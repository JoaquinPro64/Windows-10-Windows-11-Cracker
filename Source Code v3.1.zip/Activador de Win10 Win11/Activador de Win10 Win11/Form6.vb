﻿Public Class Form6
    Private Sub win10auto_Click(sender As Object, e As EventArgs) Handles win10auto.Click
        System.Diagnostics.Process.Start("Resources\auto_activ_win10.bat")
        Me.Close()
    End Sub

    Private Sub win11auto_Click(sender As Object, e As EventArgs) Handles win11auto.Click
        System.Diagnostics.Process.Start("Resources\auto_activ_win11.bat")
        Me.Close()
    End Sub
End Class