﻿Public Class Form1
    Private Sub pcinfobutton_Click(sender As Object, e As EventArgs) Handles pcinfobutton.Click
        Form3.Show()
    End Sub

    Private Sub manualbutton_Click(sender As Object, e As EventArgs) Handles manualbutton.Click
        Form2.Show()
    End Sub

    Private Sub appinfobutton_Click(sender As Object, e As EventArgs) Handles appinfobutton.Click
        Form4.Show()
    End Sub

    Private Sub exitbutton_Click(sender As Object, e As EventArgs) Handles exitbutton.Click
        Dim opcion As DialogResult
        opcion = MessageBox.Show("¿Realmente desea Salir?",
                                 "Salir del Programa",
                                 MessageBoxButtons.YesNo,
                                 MessageBoxIcon.Question)
        If (opcion = DialogResult.Yes) Then
            System.Windows.Forms.Application.Exit()
        End If
    End Sub

    Private Sub autobutton_Click(sender As Object, e As EventArgs) Handles autobutton.Click
        Form6.Show()
    End Sub
End Class
