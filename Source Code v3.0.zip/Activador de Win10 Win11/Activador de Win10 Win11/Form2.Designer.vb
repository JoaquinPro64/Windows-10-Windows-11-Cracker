﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.win10enterprise2015ltsbn = New System.Windows.Forms.Button()
        Me.win10enterprise2015ltsb = New System.Windows.Forms.Button()
        Me.win10edun = New System.Windows.Forms.Button()
        Me.win10edu = New System.Windows.Forms.Button()
        Me.win10enterprisen = New System.Windows.Forms.Button()
        Me.win10enterprise = New System.Windows.Forms.Button()
        Me.win10pron = New System.Windows.Forms.Button()
        Me.win10pro = New System.Windows.Forms.Button()
        Me.win10cs = New System.Windows.Forms.Button()
        Me.win10homesl = New System.Windows.Forms.Button()
        Me.win10homen = New System.Windows.Forms.Button()
        Me.win10home = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.win11proforworkn = New System.Windows.Forms.Button()
        Me.win11work = New System.Windows.Forms.Button()
        Me.win11edun = New System.Windows.Forms.Button()
        Me.win11edu = New System.Windows.Forms.Button()
        Me.win11pron = New System.Windows.Forms.Button()
        Me.win11pro = New System.Windows.Forms.Button()
        Me.win11homesl = New System.Windows.Forms.Button()
        Me.win11home = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(105, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(255, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Seleccione la generacion y edicion para activar:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.win10enterprise2015ltsbn)
        Me.GroupBox1.Controls.Add(Me.win10enterprise2015ltsb)
        Me.GroupBox1.Controls.Add(Me.win10edun)
        Me.GroupBox1.Controls.Add(Me.win10edu)
        Me.GroupBox1.Controls.Add(Me.win10enterprisen)
        Me.GroupBox1.Controls.Add(Me.win10enterprise)
        Me.GroupBox1.Controls.Add(Me.win10pron)
        Me.GroupBox1.Controls.Add(Me.win10pro)
        Me.GroupBox1.Controls.Add(Me.win10cs)
        Me.GroupBox1.Controls.Add(Me.win10homesl)
        Me.GroupBox1.Controls.Add(Me.win10homen)
        Me.GroupBox1.Controls.Add(Me.win10home)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 27)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(223, 378)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Windows 10"
        '
        'win10enterprise2015ltsbn
        '
        Me.win10enterprise2015ltsbn.Location = New System.Drawing.Point(6, 351)
        Me.win10enterprise2015ltsbn.Name = "win10enterprise2015ltsbn"
        Me.win10enterprise2015ltsbn.Size = New System.Drawing.Size(211, 23)
        Me.win10enterprise2015ltsbn.TabIndex = 11
        Me.win10enterprise2015ltsbn.Text = "Windows 10 Enterprise 2015 LTSB N"
        Me.win10enterprise2015ltsbn.UseVisualStyleBackColor = True
        '
        'win10enterprise2015ltsb
        '
        Me.win10enterprise2015ltsb.Location = New System.Drawing.Point(7, 322)
        Me.win10enterprise2015ltsb.Name = "win10enterprise2015ltsb"
        Me.win10enterprise2015ltsb.Size = New System.Drawing.Size(188, 23)
        Me.win10enterprise2015ltsb.TabIndex = 10
        Me.win10enterprise2015ltsb.Text = "Windows 10 Enterprise 2015 LTSB"
        Me.win10enterprise2015ltsb.UseVisualStyleBackColor = True
        '
        'win10edun
        '
        Me.win10edun.Location = New System.Drawing.Point(7, 292)
        Me.win10edun.Name = "win10edun"
        Me.win10edun.Size = New System.Drawing.Size(149, 23)
        Me.win10edun.TabIndex = 9
        Me.win10edun.Text = "Windows 10 Education N"
        Me.win10edun.UseVisualStyleBackColor = True
        '
        'win10edu
        '
        Me.win10edu.Location = New System.Drawing.Point(7, 262)
        Me.win10edu.Name = "win10edu"
        Me.win10edu.Size = New System.Drawing.Size(135, 23)
        Me.win10edu.TabIndex = 8
        Me.win10edu.Text = "Windows 10 Education"
        Me.win10edu.UseVisualStyleBackColor = True
        '
        'win10enterprisen
        '
        Me.win10enterprisen.Location = New System.Drawing.Point(7, 233)
        Me.win10enterprisen.Name = "win10enterprisen"
        Me.win10enterprisen.Size = New System.Drawing.Size(149, 23)
        Me.win10enterprisen.TabIndex = 7
        Me.win10enterprisen.Text = "Windows 10 Enterprise N"
        Me.win10enterprisen.UseVisualStyleBackColor = True
        '
        'win10enterprise
        '
        Me.win10enterprise.Location = New System.Drawing.Point(7, 202)
        Me.win10enterprise.Name = "win10enterprise"
        Me.win10enterprise.Size = New System.Drawing.Size(135, 23)
        Me.win10enterprise.TabIndex = 6
        Me.win10enterprise.Text = "Windows 10 Enterprise"
        Me.win10enterprise.UseVisualStyleBackColor = True
        '
        'win10pron
        '
        Me.win10pron.Location = New System.Drawing.Point(7, 172)
        Me.win10pron.Name = "win10pron"
        Me.win10pron.Size = New System.Drawing.Size(159, 23)
        Me.win10pron.TabIndex = 5
        Me.win10pron.Text = "Windows 10 Professional N"
        Me.win10pron.UseVisualStyleBackColor = True
        '
        'win10pro
        '
        Me.win10pro.Location = New System.Drawing.Point(7, 142)
        Me.win10pro.Name = "win10pro"
        Me.win10pro.Size = New System.Drawing.Size(149, 23)
        Me.win10pro.TabIndex = 4
        Me.win10pro.Text = "Windows 10 Professional"
        Me.win10pro.UseVisualStyleBackColor = True
        '
        'win10cs
        '
        Me.win10cs.Location = New System.Drawing.Point(7, 112)
        Me.win10cs.Name = "win10cs"
        Me.win10cs.Size = New System.Drawing.Size(210, 23)
        Me.win10cs.TabIndex = 3
        Me.win10cs.Text = "Windows 10 Home Country Specific"
        Me.win10cs.UseVisualStyleBackColor = True
        '
        'win10homesl
        '
        Me.win10homesl.Location = New System.Drawing.Point(7, 83)
        Me.win10homesl.Name = "win10homesl"
        Me.win10homesl.Size = New System.Drawing.Size(210, 23)
        Me.win10homesl.TabIndex = 2
        Me.win10homesl.Text = "Windows 10 Home Single Language"
        Me.win10homesl.UseVisualStyleBackColor = True
        '
        'win10homen
        '
        Me.win10homen.Location = New System.Drawing.Point(7, 53)
        Me.win10homen.Name = "win10homen"
        Me.win10homen.Size = New System.Drawing.Size(135, 23)
        Me.win10homen.TabIndex = 1
        Me.win10homen.Text = "Windows 10 Home N"
        Me.win10homen.UseVisualStyleBackColor = True
        '
        'win10home
        '
        Me.win10home.Location = New System.Drawing.Point(7, 23)
        Me.win10home.Name = "win10home"
        Me.win10home.Size = New System.Drawing.Size(122, 23)
        Me.win10home.TabIndex = 0
        Me.win10home.Text = "Windows 10 Home"
        Me.win10home.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.win11proforworkn)
        Me.GroupBox2.Controls.Add(Me.win11work)
        Me.GroupBox2.Controls.Add(Me.win11edun)
        Me.GroupBox2.Controls.Add(Me.win11edu)
        Me.GroupBox2.Controls.Add(Me.win11pron)
        Me.GroupBox2.Controls.Add(Me.win11pro)
        Me.GroupBox2.Controls.Add(Me.win11homesl)
        Me.GroupBox2.Controls.Add(Me.win11home)
        Me.GroupBox2.Location = New System.Drawing.Point(243, 27)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(222, 274)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Windows 11"
        '
        'win11proforworkn
        '
        Me.win11proforworkn.Location = New System.Drawing.Point(7, 233)
        Me.win11proforworkn.Name = "win11proforworkn"
        Me.win11proforworkn.Size = New System.Drawing.Size(208, 23)
        Me.win11proforworkn.TabIndex = 7
        Me.win11proforworkn.Text = "Windows 11 Pro for Workstations N"
        Me.win11proforworkn.UseVisualStyleBackColor = True
        '
        'win11work
        '
        Me.win11work.Location = New System.Drawing.Point(7, 203)
        Me.win11work.Name = "win11work"
        Me.win11work.Size = New System.Drawing.Size(153, 23)
        Me.win11work.TabIndex = 6
        Me.win11work.Text = "Windows 11 Workstations"
        Me.win11work.UseVisualStyleBackColor = True
        '
        'win11edun
        '
        Me.win11edun.Location = New System.Drawing.Point(7, 173)
        Me.win11edun.Name = "win11edun"
        Me.win11edun.Size = New System.Drawing.Size(153, 23)
        Me.win11edun.TabIndex = 5
        Me.win11edun.Text = "Windows 11 Education N"
        Me.win11edun.UseVisualStyleBackColor = True
        '
        'win11edu
        '
        Me.win11edu.Location = New System.Drawing.Point(7, 143)
        Me.win11edu.Name = "win11edu"
        Me.win11edu.Size = New System.Drawing.Size(138, 23)
        Me.win11edu.TabIndex = 4
        Me.win11edu.Text = "Windows 11 Education"
        Me.win11edu.UseVisualStyleBackColor = True
        '
        'win11pron
        '
        Me.win11pron.Location = New System.Drawing.Point(7, 113)
        Me.win11pron.Name = "win11pron"
        Me.win11pron.Size = New System.Drawing.Size(162, 23)
        Me.win11pron.TabIndex = 3
        Me.win11pron.Text = "Windows 11 Professional N"
        Me.win11pron.UseVisualStyleBackColor = True
        '
        'win11pro
        '
        Me.win11pro.Location = New System.Drawing.Point(7, 83)
        Me.win11pro.Name = "win11pro"
        Me.win11pro.Size = New System.Drawing.Size(153, 23)
        Me.win11pro.TabIndex = 2
        Me.win11pro.Text = "Windows 11 Professional"
        Me.win11pro.UseVisualStyleBackColor = True
        '
        'win11homesl
        '
        Me.win11homesl.Location = New System.Drawing.Point(7, 53)
        Me.win11homesl.Name = "win11homesl"
        Me.win11homesl.Size = New System.Drawing.Size(208, 23)
        Me.win11homesl.TabIndex = 1
        Me.win11homesl.Text = "Windows 11 Home Single Language"
        Me.win11homesl.UseVisualStyleBackColor = True
        '
        'win11home
        '
        Me.win11home.Location = New System.Drawing.Point(7, 23)
        Me.win11home.Name = "win11home"
        Me.win11home.Size = New System.Drawing.Size(121, 23)
        Me.win11home.TabIndex = 0
        Me.win11home.Text = "Windows 11 Home"
        Me.win11home.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(477, 407)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form2"
        Me.Text = "Modo Manual"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents win10enterprise2015ltsbn As Button
    Friend WithEvents win10enterprise2015ltsb As Button
    Friend WithEvents win10edun As Button
    Friend WithEvents win10edu As Button
    Friend WithEvents win10enterprisen As Button
    Friend WithEvents win10enterprise As Button
    Friend WithEvents win10pron As Button
    Friend WithEvents win10pro As Button
    Friend WithEvents win10cs As Button
    Friend WithEvents win10homesl As Button
    Friend WithEvents win10homen As Button
    Friend WithEvents win10home As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents win11proforworkn As Button
    Friend WithEvents win11work As Button
    Friend WithEvents win11edun As Button
    Friend WithEvents win11edu As Button
    Friend WithEvents win11pron As Button
    Friend WithEvents win11pro As Button
    Friend WithEvents win11homesl As Button
    Friend WithEvents win11home As Button
End Class
