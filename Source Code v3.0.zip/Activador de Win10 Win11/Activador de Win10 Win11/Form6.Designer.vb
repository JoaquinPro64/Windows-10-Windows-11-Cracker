﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form6))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.win10auto = New System.Windows.Forms.Button()
        Me.win11auto = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(2, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(233, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Seleccione la edicion de windows a activar:"
        '
        'win10auto
        '
        Me.win10auto.Location = New System.Drawing.Point(12, 35)
        Me.win10auto.Name = "win10auto"
        Me.win10auto.Size = New System.Drawing.Size(85, 23)
        Me.win10auto.TabIndex = 1
        Me.win10auto.Text = "Windows 10"
        Me.win10auto.UseVisualStyleBackColor = True
        '
        'win11auto
        '
        Me.win11auto.Location = New System.Drawing.Point(139, 33)
        Me.win11auto.Name = "win11auto"
        Me.win11auto.Size = New System.Drawing.Size(84, 25)
        Me.win11auto.TabIndex = 2
        Me.win11auto.Text = "Windows 11"
        Me.win11auto.UseVisualStyleBackColor = True
        '
        'Form6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(235, 62)
        Me.Controls.Add(Me.win11auto)
        Me.Controls.Add(Me.win10auto)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form6"
        Me.Text = "Modo Automatico"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents win10auto As Button
    Friend WithEvents win11auto As Button
End Class
